package com.live.dev.samples;


public class AlbumItem {
	public String id = null;
	public int count = 0;
	public String name = null;
	
	public AlbumItem(String pId, int pCount, String pName) {
		id = pId;
		count = pCount;
		name = pName;
	}
}
