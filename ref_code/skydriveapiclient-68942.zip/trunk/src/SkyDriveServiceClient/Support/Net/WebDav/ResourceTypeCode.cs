﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HgCo.WindowsLive.SkyDrive.Support.Net.WebDav
{
    /// <summary>
    /// 
    /// </summary>
    public enum ResourceTypeCode
    {
        /// <summary>
        /// 
        /// </summary>
        Collection,
    }
}
