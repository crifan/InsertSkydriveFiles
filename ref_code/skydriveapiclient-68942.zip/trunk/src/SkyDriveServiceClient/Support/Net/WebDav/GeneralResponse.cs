﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using HgCo.WindowsLive.SkyDrive.Support.Net;

namespace HgCo.WindowsLive.SkyDrive.Support.Net.WebDav
{
    /// <summary>
    /// 
    /// </summary>
    public class GeneralResponse : XmlWebResponse
    {
    }
}
