﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HgCo.WindowsLive.SkyDrive.Support.Net.WebDav
{
    /// <summary>
    /// 
    /// </summary>
    public static class DepthLevels
    {
        /// <summary>
        /// 
        /// </summary>
        public const string Zero = "0";
        /// <summary>
        /// 
        /// </summary>
        public const string One = "1";
        /// <summary>
        /// 
        /// </summary>
        public const string OneExcludingRoot = "1,noroot";
        /// <summary>
        /// 
        /// </summary>
        public const string Infinity = "infinity";
        /// <summary>
        /// 
        /// </summary>
        public const string InfinityExcludingRoot = "infinity,noroot";
    }
}
