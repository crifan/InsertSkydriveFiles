﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HgCo.WindowsLive.SkyDrive.Support.Net
{
    /// <summary>
    /// 
    /// </summary>
    public class XmlWebRequest
    {
    }
}
