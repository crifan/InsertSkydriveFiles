﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace HgCo.WindowsLive.SkyDrive.Services.SkyDocsService
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [XmlRoot(Namespace = "http://schemas.microsoft.com/clouddocuments")]
    public class GetProductInfoResponse : OperationResponse, IXmlSerializable
    {
        /// <summary>
        /// Gets or sets the product info.
        /// </summary>
        /// <value>
        /// The product info.
        /// </value>
        public ProductInfo ProductInfo { get; set; }

        #region IXmlSerializable Members

        /// <summary>
        /// This method is reserved and should not be used. When implementing the IXmlSerializable interface, you should return null (Nothing in Visual Basic) from this method, and instead, if specifying a custom schema is required, apply the <see cref="T:System.Xml.Serialization.XmlSchemaProviderAttribute"/> to the class.
        /// </summary>
        /// <returns>
        /// An <see cref="T:System.Xml.Schema.XmlSchema"/> that describes the XML representation of the object that is produced by the <see cref="M:System.Xml.Serialization.IXmlSerializable.WriteXml(System.Xml.XmlWriter)"/> method and consumed by the <see cref="M:System.Xml.Serialization.IXmlSerializable.ReadXml(System.Xml.XmlReader)"/> method.
        /// </returns>
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            throw new NotSupportedException();

            //var sb = new StringBuilder();
            //sb.Append("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            //sb.Append("<xs:schema xmlns:tns=\"http://schemas.microsoft.com/clouddocuments\" elementFormDefault=\"qualified\" targetNamespace=\"http://schemas.microsoft.com/clouddocuments\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\">");
            //sb.Append("<xs:element name=\"GetProductInfoResponse\">");
            //sb.Append("<xs:complexType>");
            //sb.Append("<xs:sequence>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"HomePageUrl\" nillable=\"true\" type=\"xs:string\"/>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"IsSoapEnabled\" type=\"xs:boolean\"/>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"IsSyncEnabled\" type=\"xs:boolean\"/>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"LearnMoreUrl\" nillable=\"true\" type=\"xs:string\"/>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"ProductName\" nillable=\"true\" type=\"xs:string\"/>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"ServiceDisabledErrorMessage\" nillable=\"true\" type=\"xs:string\"/>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"ShortProductName\" nillable=\"true\" type=\"xs:string\"/>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"SignInMessage\" nillable=\"true\" type=\"xs:string\"/>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"SignUpMessage\" nillable=\"true\" type=\"xs:string\"/>");
            //sb.Append("<xs:element minOccurs=\"0\" name=\"SignUpUrl\" nillable=\"true\" type=\"xs:string\"/>");
            //sb.Append("</xs:sequence>");
            //sb.Append("</xs:complexType>");
            //sb.Append("</xs:element>");
            //sb.Append("</xs:schema>");

            //System.Xml.Schema.XmlSchema schema;
            //using (var sr = new StringReader(sb.ToString()))
            //    schema = System.Xml.Schema.XmlSchema.Read(sr, null);
            //return schema;
        }

        /// <summary>
        /// Generates an object from its XML representation.
        /// </summary>
        /// <param name="reader">The <see cref="T:System.Xml.XmlReader"/> stream from which the object is deserialized.</param>
        public void ReadXml(System.Xml.XmlReader reader)
        {
            var sb = new StringBuilder(reader.ReadInnerXml());
            sb.Insert(0, "<?xml version=\"1.0\" encoding=\"utf-8\"?><ProductInfo>");
            sb.Append("</ProductInfo>");

            using (var sr = new StringReader(sb.ToString()))
            {
                var xs = new XmlSerializer(typeof(ProductInfo));
                ProductInfo = (ProductInfo)xs.Deserialize(sr);
            }
        }

        /// <summary>
        /// Converts an object into its XML representation.
        /// </summary>
        /// <param name="writer">The <see cref="T:System.Xml.XmlWriter"/> stream to which the object is serialized.</param>
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            throw new NotSupportedException();
        }

        #endregion
    }
}
