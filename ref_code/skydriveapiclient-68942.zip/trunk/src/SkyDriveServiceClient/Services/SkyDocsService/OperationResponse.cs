﻿using System;
using System.Collections.Generic;
using System.Text;
using HgCo.WindowsLive.SkyDrive.Support.Net.Soap;

namespace HgCo.WindowsLive.SkyDrive.Services.SkyDocsService
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public abstract class OperationResponse : SoapWebResponse
    {
    }
}
