﻿using System;
using System.Configuration;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace HgCo.WindowsLive.SkyDrive.Sample.ConsoleApplication
{
    /// <summary>
    /// 
    /// </summary>
    public class Program
    {
        private const string TestWebFolderName = "Testing SkyDrive API";
        private const string TestWebFileName1 = "sample.txt";
        private const string TestWebFileName2 = "sample.png";
        private const string TestWebFileName3 = "sample.url";

        /// <summary>
        /// Mains the specified args.
        /// </summary>
        /// <param name="args">The args.</param>
        [STAThread]
        public static void Main(string[] args)
        {
            // Instantiate SkyDrive API client
            var srvSkyDrive = new SkyDriveServiceClient();
            WebFolderInfo testWebFolder = null;

            try
            {
                // Log on to a user account
                srvSkyDrive.LogOn(
                    ConfigurationSettings.AppSettings["UserName"],
                    ConfigurationSettings.AppSettings["Password"]);

                // Get SkyDrive storage info
                var webDriveInfo = srvSkyDrive.GetWebDriveInfo();

                // Create a folder in SkyDrive's root
                testWebFolder = srvSkyDrive.CreateRootWebFolder(
                    TestWebFolderName, 
                    WebFolderCategoryType.Documents, 
                    WebFolderItemShareType.Private);

                // List folders in SkyDrive's root
                var rootWebFolders = srvSkyDrive.ListRootWebFolders();

                // Serialize root folders into binary format
                var serializerBinary = new BinaryFormatter();
                using (var fs = new FileStream("RootFolders.dat", FileMode.Create))
                    serializerBinary.Serialize(fs, rootWebFolders);
                // Deserialize root folders
                using (var fs = new FileStream("RootFolders.dat", FileMode.Open))
                {
                    var webFolders = serializerBinary.Deserialize(fs) as WebFolderInfo[];
                }

                // Serialize root folders into XML format
                var serializerXml = new XmlSerializer(typeof(WebFolderInfo[]));
                using (var fs = new FileStream("RootFolders.xml", FileMode.Create))
                    serializerXml.Serialize(fs, rootWebFolders);
                // Deserialize root folders
                using (var fs = new FileStream("RootFolders.xml", FileMode.Open))
                {
                    var webFolders = serializerXml.Deserialize(fs) as WebFolderInfo[];
                }

                foreach (WebFolderInfo rootWebFolder in rootWebFolders)
                    if (rootWebFolder.Name == TestWebFolderName)
                    {
                        testWebFolder = rootWebFolder;
                        break;
                    }

                //// Change folder ContentType to Documents
                //srvSkyDrive.ChangeRootWebFolderContentType(testWebFolder, WebFolderContentType.Favorites);
                //srvSkyDrive.ChangeRootWebFolderContentType(testWebFolder, WebFolderContentType.Documents);

                //// Refresh test webfolder entity
                //testWebFolder = srvSkyDrive.GetWebFolder(testWebFolder);

                //// Download test webfolder icon
                //System.Drawing.Image imgTestContentType = srvSkyDrive.DownloadWebFolderItemImage(testWebFolder.WebIcon.ContentTypeWebImage);
                //if (imgTestContentType != null)
                //    imgTestContentType.Save("TestWebFolder.ContentType.png", System.Drawing.Imaging.ImageFormat.Png);
                //System.Drawing.Image imgTestContent = srvSkyDrive.DownloadWebFolderItemImage(testWebFolder.WebIcon.ContentWebImage);
                //if (imgTestContent != null)
                //    imgTestContent.Save("TestWebFolder.Content.png", System.Drawing.Imaging.ImageFormat.Png);
                //System.Drawing.Image imgTestShareType = srvSkyDrive.DownloadWebFolderItemImage(testWebFolder.WebIcon.ShareTypeWebImage);
                //if (imgTestShareType != null)
                //    imgTestShareType.Save("TestWebFolder.ShareType.png", System.Drawing.Imaging.ImageFormat.Png);
                //System.Drawing.Image imgTestIcon = srvSkyDrive.DownloadWebFolderItemIcon(testWebFolder.WebIcon);
                //imgTestIcon.Save("TestWebFolder.Icon.png", System.Drawing.Imaging.ImageFormat.Png);

                // Create a sub folder
                var testSubWebFolder = srvSkyDrive.CreateSubWebFolder(TestWebFolderName, testWebFolder);

                // List test folder's sub folders
                var testWebFolders = srvSkyDrive.ListSubWebFolders(testWebFolder);
                //foreach (WebFolderInfo webFolder in testWebFolders)
                //{
                //    srvSkyDrive.ChangeWebFolderDescription(
                //        webFolder,
                //        String.Format("Description for {0}.", webFolder.Name));
                //    srvSkyDrive.GetWebFolder(webFolder);
                //}

                // Upload sample files
                var testWebFile1 = srvSkyDrive.UploadWebFile(TestWebFileName1, testWebFolder);
                var testWebFile2 = srvSkyDrive.UploadWebFile(TestWebFileName2, testWebFolder);
                var testWebFile3 = srvSkyDrive.UploadWebFile(TestWebFileName3, testWebFolder);

                // List test folder's files
                var testWebFiles = srvSkyDrive.ListSubWebFiles(testWebFolder);

                // Serializing files of Test folder into binary format
                using (var fs = new FileStream("TestFolderFiles.dat", FileMode.Create))
                    serializerBinary.Serialize(fs, testWebFiles);
                // Deserializing files of Test folder
                using (var fs = new FileStream("TestFolderFiles.dat", FileMode.Open))
                {
                    var webFiles = serializerBinary.Deserialize(fs) as WebFileInfo[];
                }

                // Serializing files of Test folder into XML format
                serializerXml = new XmlSerializer(typeof(WebFileInfo[]));
                using (var fs = new FileStream("TestFolderFiles.xml", FileMode.Create))
                    serializerXml.Serialize(fs, testWebFiles);
                // Deserializing files of Test folder
                using (var fs = new FileStream("TestFolderFiles.xml", FileMode.Open))
                {
                    var webFiles = serializerXml.Deserialize(fs) as WebFileInfo[];
                }

                //foreach (WebFileInfo webFile in testWebFiles)
                //{
                //    srvSkyDrive.ChangeWebFileDescription(
                //        webFile,
                //        String.Format("Description for {0}.", webFile.Name));
                //    srvSkyDrive.GetWebFile(webFile);
                //}

                // List test folder's items
                var testWebFolderItems = srvSkyDrive.ListSubWebFolderItems(testWebFolder);

                // Serializing items of Test folder into binary format
                using (var fs = new FileStream("TestFolderItems.dat", FileMode.Create))
                    serializerBinary.Serialize(fs, testWebFiles);
                // Deserializing items of Test folder
                using (var fs = new FileStream("TestFolderItems.dat", FileMode.Open))
                {
                    var webFolderItems = serializerBinary.Deserialize(fs) as WebFolderItemInfo[];
                }

                // Serializing items of Test folder into XML format
                serializerXml = new XmlSerializer(typeof(WebFolderItemInfo[]));
                using (var fs = new FileStream("TestFolderItems.xml", FileMode.Create))
                    serializerXml.Serialize(fs, testWebFiles);
                // Deserializing items of Test folder
                using (var fs = new FileStream("TestFolderItems.xml", FileMode.Open))
                {
                    var webFolderItems = serializerXml.Deserialize(fs) as WebFolderItemInfo[];
                }

                //// Download test folder as a .zip file
                //using (Stream sr = srvSkyDrive.DownloadWebFolder(testWebFolder))
                //using (FileStream fs = new FileStream(String.Format("{0}.zip", testWebFolder.Name), FileMode.OpenOrCreate))
                //{
                //    byte[] buffer = new byte[64 * 1024];
                //    int count = 0;
                //    while ((count = sr.Read(buffer, 0, buffer.Length)) > 0)
                //        fs.Write(buffer, 0, count);
                //}
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadLine();
            }
            finally
            {
                if (testWebFolder != null)
                {
                    // Delete test folder recursively
                    srvSkyDrive.DeleteWebFolder(testWebFolder);
                }
            }
        }

    }
}