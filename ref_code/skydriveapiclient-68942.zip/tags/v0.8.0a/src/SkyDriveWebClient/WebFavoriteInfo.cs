﻿using System;

namespace HgCo.WindowsLive.SkyDrive
{
    /// <summary>
    /// Provides favorite webfile content specific data.
    /// </summary>
    public class WebFavoriteInfo : WebFileInfo
    {
        #region Properties
        
        /// <summary>
        /// Gets or sets the web address.
        /// </summary>
        /// <value>The web address.</value>
        public Uri WebAddress { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="WebFavoriteInfo"/> class.
        /// </summary>
        public WebFavoriteInfo()
            : base()
        {
        }

        #endregion
    }
}
