﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using Styles = DiggThis.DiggThisHeaderFooterSource.Styles;

namespace DiggThis
{
    internal partial class DiggBadgeConfigForm : Form
    {
        public DiggBadgeConfigForm()
        {
            InitializeComponent();
        }

        public bool AlignRight
        {
            get { return (string)cbAlign.SelectedItem == "Right"; }
            set { cbAlign.SelectedItem = value ? "Right" : "Left"; }
        }

        public Styles Style
        {
            get { return (Styles) Enum.Parse(typeof(Styles), (string)cbStyle.SelectedItem); }
            set { cbStyle.SelectedItem = value.ToString(); }
        }

        private void UpdatePreview()
        {
            lblWarn.Visible = cbStyle.SelectedIndex >= 0 && cbStyle.SelectedIndex <= 1;

            if (cbAlign.SelectedIndex < 0 || cbStyle.SelectedIndex < 0)
                return;

            string resourceName = string.Format("DiggThis.Preview{0}{1}.png",
                cbStyle.SelectedItem,
                cbAlign.SelectedItem);

            Assembly a = Assembly.GetExecutingAssembly();
            Stream resStream = a.GetManifestResourceStream(resourceName);
            if (resStream != null)
                picPreview.Image = Bitmap.FromStream(resStream);
            else
                picPreview.Image = null;
        }

        private void cbStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdatePreview();
        }

        private void cbAlign_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdatePreview();
        }
    }
}
