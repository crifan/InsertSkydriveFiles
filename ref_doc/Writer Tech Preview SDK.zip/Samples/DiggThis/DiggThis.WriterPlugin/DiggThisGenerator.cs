﻿using System;
using System.Collections.Generic;
using System.Text;
using WindowsLive.Writer.Api;
using System.Web;
using System.Diagnostics;
using System.Globalization;
using System.Drawing;

namespace DiggThis
{
    /// <summary>
    /// Methods to help generate Digg badges.
    /// </summary>
    public static class DiggThisGenerator
    {
        public static string GenerateJSBadge(string url, string title, Color? backgroundColor, string skin)
        {
            const string template = @"<script type=""text/javascript"">digg_url = ""{0}"";digg_title = ""{1}"";digg_bgcolor = ""{2}"";digg_skin = ""{3}"";</script>"
                + @"<script src=""http://digg.com/tools/diggthis.js"" type=""text/javascript""></script>" 
                + @"<script type=""text/javascript"">digg_url = undefined;digg_title = undefined;digg_bgcolor = undefined;digg_skin = undefined;</script>";

            return string.Format(CultureInfo.InvariantCulture,
                template,
                JsEscape(url),
                JsEscape(title),
                JsEscape(ColorToRgb(backgroundColor ?? Color.White)),
                JsEscape(skin));
        }

        public static string GenerateStaticBadge(string url, string title, string imgSrc, Size imgSize)
        {
            const string template = @"<a href=""{0}""><img src=""{1}"" width=""{2}"" height=""{3}"" alt=""Digg This"" title=""Digg This"" border=""0"" style=""border: 0"" /></a>";

            string diggUrl = BuildUrl("http://digg.com/submit",
                true,
                "url", url,
                "title", title);

            return string.Format(
                CultureInfo.InvariantCulture, 
                template,
                HttpUtility.HtmlEncode(diggUrl), 
                HttpUtility.HtmlEncode(imgSrc), 
                imgSize.Width, 
                imgSize.Height);
        }

        /// <summary>
        /// Converts colors to their #RRGGBB representation.
        /// </summary>
        private static string ColorToRgb(Color? color)
        {
            if (color == null)
                return null;
            return string.Format(CultureInfo.InvariantCulture, 
                "#{0:X2}{1:X2}{2:X2}",
                color.Value.R, color.Value.G, color.Value.B);
        }

        /// <summary>
        /// Escapes some (not all) special characters from a string
        /// to make it suitable for embedding as a literal.
        /// </summary>
        private static string JsEscape(string value)
        {
            if (string.IsNullOrEmpty(value))
                return value;

            return value
                .Replace(@"\", @"\\")
                .Replace("\r", @"\r")
                .Replace("\n", @"\n")
                .Replace("'", @"\'")
                .Replace("\"", @"\""")
                .Replace("<", @"\u003C");
        }

        /// <summary>
        /// Performs URL escaping on the given string, or simply
        /// passes it through if null.
        /// </summary>
        private static string UrlEscape(string value)
        {
            if (value == null)
                return null;
            return HttpUtility.UrlEncode(value);
        }

        /// <summary>
        /// Turns string arguments into a query string (optionally performing
        /// escaping) and appends them to a URL.
        /// </summary>
        private static string BuildUrl(string baseUrl, bool escape, params string[] args)
        {
            if ((args.Length % 2) != 0)
                throw new ArgumentException("Invalid number of args, even number expected");

            StringBuilder sb = new StringBuilder(baseUrl);
            string delim = baseUrl.Contains("?") ? "&" : "?";
            for (int i = 0; i < args.Length; i += 2)
            {
                string name = args[i];
                string val = args[i + 1];

                // Ignore null/empty names or values. This makes it
                // much easier to have conditional arguments.
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(val))
                    continue;

                if (escape)
                {
                    name = UrlEscape(name);
                    val = UrlEscape(val);
                }

                sb.Append(delim);
                delim = "&";
                sb.Append(name);
                sb.Append('=');
                sb.Append(val);
            }
            return sb.ToString();
        }
    }
}
