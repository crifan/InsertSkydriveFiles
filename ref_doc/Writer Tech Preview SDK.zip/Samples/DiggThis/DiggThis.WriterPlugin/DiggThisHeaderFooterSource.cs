﻿using System;
using System.Collections.Generic;
using System.Text;
using WindowsLive.Writer.Api;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.Drawing;

namespace DiggThis
{
    [WriterPlugin("5A231BD1-9D44-4f51-9C46-E58DEEB33141", "DiggThis",
        HasEditableOptions=true,
        ImagePath="DiggIcon.png",
        Description="Automatically embeds a DiggThis badge when posts are published.")]
    public class DiggThisHeaderFooterSource : HeaderFooterSource
    {
        /// <summary>
        /// The different styles of Digg badges that are supported
        /// by this plugin.
        /// </summary>
        internal enum Styles
        {
            Badge,
            Compact,
            Button,
            Guy
        }

        public override bool RequiresPermalink
        {
            get { return true; }
        }

        /// <summary>
        /// Lets the user choose the style and alignment of the badge.
        /// </summary>
        public override void EditOptions(IWin32Window dialogOwner)
        {
            using (DiggBadgeConfigForm configForm = new DiggBadgeConfigForm())
            {
                configForm.AlignRight = AlignRight;
                configForm.Style = Style;
                
                if (DialogResult.OK == configForm.ShowDialog(dialogOwner))
                {
                    AlignRight = configForm.AlignRight;
                    Style = configForm.Style;
                }
            }
        }

        /// <summary>
        /// Gets or sets a persistent setting indicating whether the
        /// badge should be aligned to the right.
        /// </summary>
        private bool AlignRight
        {
            get { return Options.GetString("Align", "Right") == "Right"; }
            set { Options.SetString("Align", value ? "Right" : "Left"); }
        }

        /// <summary>
        /// Gets or sets a persistent setting indicating what style
        /// of badge should be used.
        /// </summary>
        private Styles Style
        {
            get
            {
                try
                {
                    string style = Options.GetString("Style", Styles.Badge.ToString());
                    return (Styles) Enum.Parse(typeof(Styles), style);
                }
                catch (ArgumentException)
                {
                    return Styles.Badge;
                }
            }
            set { Options.SetString("Style", value.ToString()); }
        }

        public override string GeneratePreviewHtml(
            ISmartContent smartContent, 
            IPublishingContext publishingContext,
            out Position position)
        {
            string url = "http://www.microsoft.com";
            return GenerateBadge(
                smartContent, 
                url, 
                publishingContext.PostInfo.Title, 
                publishingContext.BodyBackgroundColor, 
                publishingContext.SupportsScripts != SupportsFeature.No,
                out position);
        }

        public override string GeneratePublishHtml(
            IWin32Window dialogOwner, 
            ISmartContent smartContent, 
            IPublishingContext publishingContext, 
            bool publish, 
            out Position position)
        {
            if (string.IsNullOrEmpty(publishingContext.PostInfo.Permalink))
            {
                Debug.Fail("No permalink!");
                position = Position.Footer;
                return string.Empty;
            }

            return GenerateBadge(
                smartContent, 
                publishingContext.PostInfo.Permalink, 
                publishingContext.PostInfo.Title, 
                publishingContext.BodyBackgroundColor, 
                publishingContext.SupportsScripts != SupportsFeature.No, 
                out position);
        }

        private string GenerateBadge(
            ISmartContent smartContent, 
            string url, 
            string title, 
            Color? bgColor, 
            bool supportsScript, 
            out Position position)
        {
            smartContent.Layout.Alignment = AlignRight ? Alignment.Right : Alignment.Left;
            smartContent.Layout.TopMargin = 4;
            smartContent.Layout.BottomMargin = 4;
            smartContent.Layout.LeftMargin = 0;
            smartContent.Layout.RightMargin = 0;

            switch (Style)
            {
                case Styles.Badge:
                    if (!supportsScript)
                        goto case Styles.Button;
                    position = Position.Header;
                    smartContent.Layout.TopMargin = 0;
                    if (AlignRight)
                        smartContent.Layout.LeftMargin = 8;
                    else
                        smartContent.Layout.RightMargin = 8;
                    return DiggThisGenerator.GenerateJSBadge(url, title, bgColor, "normal");

                case Styles.Compact:
                    if (!supportsScript)
                        goto case Styles.Button;
                    position = Position.Footer;
                    return DiggThisGenerator.GenerateJSBadge(url, title, bgColor, "compact");

                case Styles.Button:
                    position = Position.Footer;
                    Size size = new Size(100, 20);
                    return DiggThisGenerator.GenerateStaticBadge(url, title, 
                        "http://digg.com/img/badges/100x20-digg-button.png",
                        new Size(100, 20));

                case Styles.Guy:
                    position = Position.Footer;
                    return DiggThisGenerator.GenerateStaticBadge(url, title,
                        "http://digg.com/img/badges/16x16-digg-guy.png",
                        new Size(16, 16));

                default:
                    goto case Styles.Badge;
            }
        }
    }
}
