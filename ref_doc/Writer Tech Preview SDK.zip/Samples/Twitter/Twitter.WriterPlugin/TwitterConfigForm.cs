﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TwitterPlugin
{
    public partial class TwitterConfigForm : Form
    {
        private bool fullOptionsVisible = true;

        /// <summary>
        /// A value to "stand in" for the real password as the
        /// default value for the textbox. We don't want it to
        /// be possible to use a password sniffing program to
        /// uncover the cleartext password.
        /// </summary>
        private string defaultPasswordCookie;
        private string defaultPassword;

        public TwitterConfigForm()
        {
            InitializeComponent();
        }

        public string Username
        {
            get { return txtUsername.Text; }
            set { txtUsername.Text = value; }
        }

        public string Password
        {
            get
            {
                if (txtPassword.Text == defaultPasswordCookie)
                    return defaultPassword;
                else
                    return txtPassword.Text;
            }
            set
            {
                defaultPassword = value;
                defaultPasswordCookie = CreateCookie(value);
                txtPassword.Text = defaultPasswordCookie;
            }
        }

        public string StatusFormat
        {
            get { return txtMessageFormat.Text; }
            set { txtMessageFormat.Text = value; }
        }

        public bool ShowFullOptions
        {
            set
            {
                Text = value ? "Twitter Options" : "Twitter Login";

                if (Created)
                    throw new InvalidOperationException("ShowStatusFormat property should be set before the form is loaded");

                if (value != fullOptionsVisible)
                {
                    fullOptionsVisible = value;

                    Height += (panelFullOptions.Bottom - txtPassword.Bottom)
                        * (value ? 1 : -1);

                    panelFullOptions.Visible = value;
                }
            }
        }

        /// <summary>
        /// Creates a string of the same length as the real password,
        /// but containing only characters that would not likely be 
        /// present in any legitimate password.
        /// </summary>
        private static string CreateCookie(string password)
        {
            if (password == null)
                return null;
            return new string('\xFFFD', password.Length);
        }
    }
}
