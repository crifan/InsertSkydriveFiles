﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Media;

namespace TwitterPlugin
{
    public partial class TwitterNotifyForm : Form
    {
        private const int MAXLEN = 140;
        private Font countFont;

        public TwitterNotifyForm()
        {
            InitializeComponent();
            countFont = new Font("Georgia", 14.25f, FontStyle.Bold, GraphicsUnit.Point);
        }

        /// <summary>
        /// Gets or sets the status message that is displayed
        /// in the main textbox.
        /// </summary>
        public string Status
        {
            get { return txtStatus.Text; }
            set
            {
                txtStatus.Text = value;
                txtStatus.Select(txtStatus.TextLength, 0);
            }
        }

        private void txtStatus_TextChanged(object sender, EventArgs e)
        {
            // Causes the characters remaining to repaint themselves
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            int count = MAXLEN - txtStatus.TextLength;
            string countStr = count.ToString(CultureInfo.CurrentCulture);
            
            Rectangle bounds = new Rectangle(
                txtStatus.Left, 
                txtStatus.Top - countFont.Height - 4, 
                txtStatus.Width, 
                countFont.Height);
            
            TextRenderer.DrawText(
                e.Graphics, 
                countStr, 
                countFont, 
                bounds, 
                count >= 10 ? Color.White : Color.Red, 
                TextFormatFlags.Right | TextFormatFlags.NoPadding | TextFormatFlags.NoClipping);
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (Status.Length > MAXLEN)
            {
                SystemSounds.Hand.Play();
            }
            else
            {
                DialogResult = DialogResult.OK;
            }
        }
    }
}
