﻿using System.IO;
using System.Net;
using System.Net.Cache;
using System.Reflection;
using System.Text;
using System.Web;
using WindowsLive.Writer.Api;

namespace TwitterPlugin
{
    static class TwitterApi
    {
        /// <summary>
        /// Returns true if the credentials are valid.
        /// </summary>
        public static bool VerifyCredentials(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                return false;

            try
            {
                TaskServices.ExecuteWithResponsiveUI(delegate
                {
                    HttpWebRequest req = CreateRequest(
                        "https://twitter.com/account/verify_credentials.xml",
                        "GET",
                        username,
                        password);

                    req.Timeout = 30000;
                    req.ReadWriteTimeout = 30000;

                    req.GetResponse().Close();
                });
                return true;
            }
            catch (WebException we)
            {
                if (we.Response != null
                    && we.Response is HttpWebResponse
                    && ((HttpWebResponse)we.Response).StatusCode == HttpStatusCode.Unauthorized)
                {
                    return false;
                }

                throw;
            }
        }

        /// <summary>
        /// Updates the Twitter status of the specified user.
        /// </summary>
        public static void UpdateStatus(string username, string password, string status)
        {
            TaskServices.ExecuteWithResponsiveUI(delegate
            {
                HttpWebRequest req = CreateRequest(
                    "https://twitter.com/statuses/update.xml", 
                    "POST",
                    username,
                    password);

                req.Timeout = 30000;
                req.ReadWriteTimeout = 30000;

                string escaped = HttpUtility.UrlEncode(status);
                byte[] bytes = new UTF8Encoding(false, false).GetBytes("status=" + escaped);

                using (Stream s = req.GetRequestStream())
                {
                    s.Write(bytes, 0, bytes.Length);
                }

                req.GetResponse().Close();
            });
        }

        private static HttpWebRequest CreateRequest(string url, string method, string username, string password)
        {
            HttpWebRequest req = (HttpWebRequest) WebRequest.Create(url);
            req.Method = method;
            req.CachePolicy = new RequestCachePolicy(RequestCacheLevel.Reload);
            req.Headers.Add("X-Twitter-Client", "Windows Live Writer Plugin");
            req.Headers.Add("X-Twitter-Client-URL", "http://windowslivewriter.spaces.live.com/");
            req.Headers.Add("X-Twitter-Client-Version",
                Assembly.GetExecutingAssembly().GetName().Version.ToString());

            if (username != null)
                req.Credentials = new NetworkCredential(username, password);
            
            return req;
        }
    }
}
