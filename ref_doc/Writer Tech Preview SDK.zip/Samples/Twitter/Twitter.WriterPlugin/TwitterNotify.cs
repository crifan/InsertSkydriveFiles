﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using WindowsLive.Writer.Api;
using System.Web;
using System.ComponentModel;

namespace TwitterPlugin
{
    [WriterPlugin("CECF2903-51B3-4173-A932-76E4EE4C01CF", "Twitter Notify",
        HasEditableOptions=true,
        ImagePath="TwitterIcon.png",
        Description="Prompts you to send a Twitter whenever you publish a new post.")]
    public class TwitterNotify : PublishNotificationHook
    {
        #region Global Settings

        /// <summary>
        /// Gets or sets the format that should be used to create the default
        /// update message. {0} is the post permalink, {2} is the post title.
        /// </summary>
        public string UpdateFormat
        {
            get { return Options.GetString("StatusFormat", "New blog post: {0} - {1}"); }
            set
            {
                // Empty string means revert to default
                if (value == "")
                    value = null;
                Options.SetString("StatusFormat", value);
            }
        }

        /// <summary>
        /// Gets or sets Twitter username.
        /// </summary>
        public string Username
        {
            get { return Options.GetString("Username", null); }
            set { Options.SetString("Username", value); }
        }

        /// <summary>
        /// Gets or sets Twitter password.
        /// </summary>
        public string Password
        {
            get { return Decrypt(Options.GetString("Password", null)); }
            set { Options.SetString("Password", Encrypt(value)); }
        }

        private string UrlShortener
        {
            get
            {
                // {0} is the long URL, {1} is the same but URL-encoded.
                //
                // Other possibilities:
                // http://is.gd/api.php?longurl={0}
                // http://snipr.com/site/snip?r=simple&link={1}
                // http://snurl.com/site/snip?r=simple&link={1}
                // {0}

                string format = Options.GetString("UrlShortener", null);
                return !string.IsNullOrEmpty(format) ? format : "http://tinyurl.com/api-create.php?url={0}";
            }
        }

        #endregion

        public override void OnPostPublish(IWin32Window owner, IProperties properties, IPublishingContext publishingContext, bool publish)
        {
            if (!publish) // User is posting as draft
                return;

            // Protect against the possibility of blog services that don't return permalinks
            if (string.IsNullOrEmpty(publishingContext.PostInfo.Permalink))
            {
                PluginDiagnostics.LogError("TwitterNotify didn't execute, due to blank permalink");
                return;
            }

            // If we don't have valid credentials, ask for new ones.
            if (!TwitterApi.VerifyCredentials(Username, Password))
            {
                if (!PromptForLogin(owner, false))
                    return;
            }

            if (!properties.GetBoolean("Send", true))
                return;

            string status;
            using (TwitterNotifyForm form = new TwitterNotifyForm())
            {
                form.Status = GenerateDefaultStatus(publishingContext);

                DialogResult result = form.ShowDialog(owner);
                if (result != DialogResult.OK)
                {
                    // The user hit cancel; don't set an update now and don't
                    // prompt them to update again for this post.
                    properties.SetBoolean("Send", false);
                    return;
                }

                status = form.Status;
            }

            Cursor.Current = Cursors.WaitCursor;
            try
            {
                TwitterApi.UpdateStatus(Username, Password, status);
                
                // Updating Twitter often happens so quickly that
                // it doesn't feel like enough time has passed for
                // it to have worked. So sleep for 250 millis to
                // make the user feel like something happened.
                Thread.Sleep(250);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }

            // We've successfully sent an update--never do it again for this post
            properties.SetBoolean("Send", false);
        }

        public override void EditOptions(IWin32Window dialogOwner)
        {
            PromptForLogin(dialogOwner, true);
        }

        /// <summary>
        /// Show a username/password form, and if valid, save the credentials
        /// to the plugin settings store.
        /// </summary>
        /// <returns>True if the username/password was successfully
        /// entered, confirmed, and persisted; false if the user
        /// hit Cancel.</returns>
        private bool PromptForLogin(IWin32Window dialogOwner, bool showFullOptions)
        {
            using (TwitterConfigForm form = new TwitterConfigForm())
            {
                form.ShowFullOptions = showFullOptions;

                form.Username = Username;
                form.Password = Password;
                if (showFullOptions)
                    form.StatusFormat = UpdateFormat.Replace("{0}", "{url}").Replace("{1}", "{title}");

                // Check the credentials before letting the form close
                form.Closing += ConfirmCredentials;

                DialogResult result = form.ShowDialog(dialogOwner);
                if (result != DialogResult.OK)
                    return false;

                Username = form.Username;
                Password = form.Password;
                if (showFullOptions)
                    UpdateFormat = form.StatusFormat.Replace("{url}", "{0}").Replace("{title}", "{1}");
                return true;
            }
        }

        private void ConfirmCredentials(object sender, CancelEventArgs args)
        {
            TwitterConfigForm form = (TwitterConfigForm) sender;
            if (form.DialogResult != DialogResult.OK || args.Cancel)
                return;

            form.Cursor = Cursors.WaitCursor;
            form.Enabled = false;
            try
            {
                if (!TwitterApi.VerifyCredentials(form.Username, form.Password))
                {
                    args.Cancel = true;
                    MessageBox.Show(
                        form,
                        "Wrong username and password combination.\r\n\r\nPlease try again.",
                        "Login Failed",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Exclamation);
                }
            }
            catch (WebException e)
            {
                args.Cancel = true;
                PluginDiagnostics.LogException(e);
                PluginDiagnostics.DisplayError("Error verifying username/password", e.Message);
            }
            finally
            {
                form.Enabled = true;
                form.Cursor = Cursors.Default;
            }
        }

        /// <summary>
        /// Creates a default status message which can be used to prepopulate
        /// the Twitter update form.
        /// </summary>
        private string GenerateDefaultStatus(IPublishingContext publishingContext)
        {
            string url = MakeTinyUrl(publishingContext.PostInfo.Permalink);
            string title = publishingContext.PostInfo.Title;
            return string.Format(UpdateFormat, url, title);
        }

        private string MakeTinyUrl(string url)
        {
            if (UrlShortener.Length == 0)
                return url;

            return TaskServices.ExecuteWithResponsiveUI(url, delegate
            {
                using (WebClient wc = new WebClient())
                    return wc.DownloadString(string.Format(UrlShortener, url, HttpUtility.UrlEncode(url)));
            });
        }

        /// <summary>
        /// Encrypt a string using DPAPI.
        /// </summary>
        private static string Encrypt(string s)
        {
            if (s == null)
                return null;

            byte[] entropy = new byte[16];

            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            rng.GetBytes(entropy);

            byte[] secretBytes = Encoding.Unicode.GetBytes(s);
            byte[] encrypted = ProtectedData.Protect(
                secretBytes, entropy, DataProtectionScope.CurrentUser);

            byte[] package = new byte[entropy.Length + encrypted.Length];
            Array.Copy(entropy, package, 16);
            Array.Copy(encrypted, 0, package, 16, encrypted.Length);

            return Convert.ToBase64String(package);
        }

        /// <summary>
        /// Decrypt a string using DPAPI.
        /// </summary>
        private static string Decrypt(string s)
        {
            if (s == null)
                return null;

            try
            {
                byte[] package = Convert.FromBase64String(s);
                byte[] entropy = new byte[16];
                byte[] encrypted = new byte[package.Length - 16];
                Array.Copy(package, entropy, 16);
                Array.Copy(package, 16, encrypted, 0, encrypted.Length);

                byte[] secretBytes = ProtectedData.Unprotect(
                    encrypted, entropy, DataProtectionScope.CurrentUser);
                return Encoding.Unicode.GetString(secretBytes);
            }
            catch (FormatException)
            {
                return null;
            }
            catch (CryptographicException)
            {
                return null;
            }
        }
    }
}
