To install the sample plugins, copy Twitter.WriterPlugin.dll
and DiggThis.WriterPlugin.dll to the following directory:

C:\Program Files\Windows Live\Writer\Plugins\
