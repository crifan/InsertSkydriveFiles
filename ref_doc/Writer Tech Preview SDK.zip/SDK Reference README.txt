If you have trouble viewing "SDK Reference.chm", please follow these
instructions carefully:

  1. Copy the "SDK Reference.chm" file to your local hard drive.
  2. Right-click on the file in Windows Explorer and select Properties.
  3. Click "Unblock" (near the bottom-right corner of the General tab).

(See http://support.microsoft.com/kb/902225 for more information.)